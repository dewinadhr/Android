<?php

namespace App\Http\Controllers;
use DB;

class ContactController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function getData(){
        $contact = DB::table('contact')->get();
        return response([
            'success' => true,
            'result' => $contact
        ]);
    }

    //
}
