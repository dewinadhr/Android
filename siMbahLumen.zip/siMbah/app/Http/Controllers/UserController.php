<?php

namespace App\Http\Controllers;
use DB;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function getData(){
        $users = DB::table('user')->get();
        return response([
            'success' => true,
            'result' => $users
        ]);
    }

    //
}
