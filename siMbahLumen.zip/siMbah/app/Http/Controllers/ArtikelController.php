<?php

namespace App\Http\Controllers;
use DB;
use \Illuminate\Http\Request;

class ArtikelController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function getData(){
        $artikel = DB::table('artikel')->get();
        return response([
            'success' => true,
            'result' => $artikel
        ],200);
    }

    public function postData(Request $request)
    {
        $title = $request->title;
        $news_title = $request->news_title;


        DB::table('artikel')->insert([
            ['title' => $title, 'news_title' => $news_title]
        ]);
         return response([
            'success' => true,
            'result' => 'success'
        ],200);
    }

    public function deleteData($id)
    {

        DB::table('artikel')->where('id', $id)->delete();
        return response([
            'success' => true,
            'result' => 'success'
        ],200);
    }

     public function updateData(Request $request, $id)
    {

        DB::table('artikel')->where('id', $id)->update([
            'title'=>$request->title,
            'news_title'=>$request->news_title
        ]);
        return response([
            'success' => true,
            'result' => 'success'
        ],200);
    }

    //
}
